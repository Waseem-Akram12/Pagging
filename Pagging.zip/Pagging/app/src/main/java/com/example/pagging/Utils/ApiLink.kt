package com.example.pagging.Utils

object ApiLink {
//    https://dummyjson.com/users
    const val Base_Url = "https://dummyjson.com"

}