package com.example.pagging.model

data class Hair(
    val color: String,
    val type: String
)