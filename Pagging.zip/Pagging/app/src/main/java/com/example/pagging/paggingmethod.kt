package com.example.pagging

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class paggingmethod : Application() {
}